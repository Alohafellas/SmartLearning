<?php
include('connection.php');
session_start();
     ?>
     <head>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
     </head>
<h1>Videos </h1>
<div class="container" onload=" disableAutoplay()">
<?php
     $fetchVideos = mysqli_query($conn, "SELECT * FROM lesson ");
     while($row = mysqli_fetch_array($fetchVideos)){
       $name=$row['FileLocation'];
       $title=$row['LessonTitle'];
 ?>
  <div class="row">
    <div class="col-md-6 ">
      <div class="card">
        <div class="card-image">
          <div class="embed-responsive embed-responsive-16by9">
            <video id="vid" width="300" height="230" src="<?php echo $name;?>" frameborder="0" controls></video>

        </div>


        <div class="card-content">
          <span class="card-title"><?php echo $title;?></span>
        
        </div>


      </div>
    </div>



</div>
<?php
     }
?>
<style>


.card{
  margin-top: 25%;
justify-content: center;

}

.card .card-content {
    padding: 10px;
  
}
h1{
  text-decoration: underline;
  letter-spacing: 0.1rem;
  text-align: center;
  font-weight: bold;
  font-family:sans-serif;
  margin-bottom: -3.5%;
}
.card .card-content .card-title, .card-reveal .card-title{
    font-size: 20px;
    font-weight: 100;
  margin-bottom:10px;
}

.container .content {
    position: center;
    bottom: 0;
    background: rgba(0, 0, 0, 0.5); 
    color: #f1f1f1;
    padding-top:5px;
 
    text-align: right;
    margin-left:90px;
    padding-right:15px;
    
}

</style>
<script>
  var x = document.getElementById("vid");
function disableAutoplay() { 
  x.autoplay = false;
  x.load();
} 

const video = document.querySelector("video");
const videoId = video.src;
let intervalHandle = null;


video.addEventListener("play", (event) => {
  intervalHandle = setInterval(() => {
    savePosition(videoId, video.currentTime);
  }, 5000)
})

video.addEventListener("pause", (event) => {
  clearInterval(intervalHandle);
})

const getPosition = (videoId) => {
  // fetch(url) ...
  const defaultPosition = {
    videoId,
    position: 0
  }

  try {
    return localStorage.getItem("position") || defaultPosition;
  } catch (error) {

  }

  return defaultPosition;
}

const savePosition = (videoId, position) => {
  // fetch(url, {method: 'POST', body: {videoId, position}}) ...
  try {
    localStorage.setItem("position", JSON.stringify({
      videoId,
      position
    }));
  } catch (error) {}
}

const result = getPosition(videoId);

video.currentTime = result.position;
    </script>
