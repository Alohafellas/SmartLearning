<?php

include("connection.php");
include('login.php');


        ?>  
        
        <tr>  
        <td>
          <td><?php echo $_POST['UName'];?></td>
          <td><?php echo $_SESSION['Email'];?></td>
  
        <?php  ?>  