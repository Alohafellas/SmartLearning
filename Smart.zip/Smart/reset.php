<?php
include('connection.php');
session_start();
$old=$_POST['old'];
$new=$_POST['new'];
$cnf=$_POST['cnf'];

if($new==$cnf){
    $query="UPDATE registration set UPassword=$new where Email='".$_SESSION['Email']."'";
  //  $query="UPDATE registration set UPassword='$new' where UName='".$_SESSION['UName']."' and  Email='".$_SESSION['Email']."'";
    $result=mysqli_query($conn,$query);
    if (!mysqli_query($conn, $query)) {
        echo "Error: " . mysqli_error($conn);
      }
   else if($result){
        header('location:d.php');
    }
}
else{
    echo 'New password doesnt match';
}