<?php

include ('connection.php');
session_start();
$message = $Home = '';
$name = $_POST['name'];
$gender=$_POST['gender'];
$email = $_POST['email'];
$pswd = $_POST['pswd'];
$pattern = "^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$^";  
$sql = "INSERT INTO registration VALUES (NULL,'$name','$gender','$email','$pswd')";   
$sql1="SELECT * from registration where (UName='$name' and Email='$email');";
$res=mysqli_query($conn, $sql1);

 if (strlen ($pswd) != 6) {  
   $message = "<div class='alert alert-danger'>Password must be of 6 characters..!!</div>";
   /* echo '<script type ="text/JavaScript">';  
    echo 'alert("Password must be of 6 digits.")';  
    echo '</script>';*/
    }
 else if (mysqli_num_rows($res) > 0) 
    {
        
        $row = mysqli_fetch_assoc($res);
         if ($name==$row['UName'] && $email==$row['Email'])
        {
          $message = "<div class='alert alert-danger'>User Already Exists..!!</div>";
         /* echo '<script type ="text/JavaScript">';  
    echo 'alert("User already exists")';  
    echo '</script>';
    echo '';  */
    header('loaction:signup.php');
        }
    }
 else if (!preg_match ($pattern, $email) )

 {  
   $message = "<div class='alert alert-danger'>Email not valid!!</div>";
    /*echo '<script type ="text/JavaScript">';  
    echo 'alert("Email in not valid")';  
    echo '</script>';
    echo '';  */
         
}


else if(mysqli_query($conn, $sql)){
   $message = "<div class='alert alert-success'>Registered Successfully..</div>";
 //  echo "Registered succesfully";
   header('location:signin.php');
}  


else{
   $message = "<div class='alert alert-danger'>Some Error Occurred!!</div>";
  /* echo "ERROR: Hush! Sorry $sql. "
	   . mysqli_error($conn);*/
}


?>
