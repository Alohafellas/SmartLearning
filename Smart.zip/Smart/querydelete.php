<?php
include('connection.php');


$id=$_GET['ID'];
$q="DELETE from contactus where ID='$id'";
$res=mysqli_query($conn,$q);
if($res)
{
    echo '<script type ="text/JavaScript">';
    echo 'location.replace("admin.php");';
    echo ' </script>';
}
?>