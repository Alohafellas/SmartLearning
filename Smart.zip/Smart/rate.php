<?php
include('connection.php');
include('d.php');


if(isset($_POST['submit'])) {
$id=$_SESSION['ID'];
$name=$_SESSION['UName'];
$email=$_SESSION['Email'];
$rmsg=$_POST['rate'];
$cmnt=$_POST['msg'];
$query = "INSERT INTO `feedback` VALUES (NULL,'$name','$email','$rmsg','$cmnt',Null) ";   
$result=mysqli_query($conn,$query);

if($result){
  echo '<script type ="text/JavaScript">';
  echo 'location.replace("d.php");';
  echo ' </script>';

}}
?>
