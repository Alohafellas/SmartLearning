
<?php
    include('connection.php');
 session_start();
 $query="SELECT * from registration where ID='".$_SESSION['ID']."'";
 $result=mysqli_query($conn,$query);
 $total=mysqli_num_rows($result);
 if($total==1)
 {
     while($row=mysqli_fetch_array($result))
     {
      $_SESSION['ID']=$row['ID'];
     ?>
 

   
<head>
    <script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
    <link rel="stylesheet" href="prof.css">
</head>
<body>

<div class="wrapper">

    <div class="profile">
        <div class="profile_img_info">         
             <div class="img">
               <img src="images/User-512.png">
             </div>
             <div class="info">
           <span class="title"><?php echo $row['UName'];?></span>
             </div>
        </div>
        <div class="profile_skills">
        <form class="contact-form row" accept-charset="UTF-8" action="sud.php" method="POST" >
            <div class="skills">
                <p>MY Profile </p>
                <ul>
              
        
              
        <div class="form-field col-sm-8">
         <input id="name" name="name" class="input-text js-input" type="text" required value=" <?php echo $row['UName'];?>">
         <label class="label" for="name">Username</label>
        </div>
        <div class="form-field col-sm-8">
         <input id="name" name="gender" class="input-text js-input" type="text" required value=" <?php echo $row['Gender'];?>">
         <label class="label" for="name">Gender</label>
        </div>
        <div class="form-field col-sm-8">
         <input id="name" name="email" class="input-text js-input" type="text" required value=" <?php echo $row['Email'];?>">
         <label class="label" for="name">Email</label>
        </div>
        <div class="form-field col x-150 align-center">
         <input class="submit-btn" type="submit" value="Update">
      </div>
               
            
    
                </ul>
            </div>
            
        </div>
    </div>

</div>
</body>

<?php
     }}
     ?>
<style>

@import url(https://fonts.googleapis.com/css?family=Raleway:300);
@import url(https://fonts.googleapis.com/css?family=Lusitana:400,700);



.align-center {
   text-align: center;
}



body {

width:auto;
   position: center;
   margin-left: 5%;
}

.row {

   margin: -20px 0;}
   .col {
      padding: 0 20px;
      float: left;
      box-sizing: border-box;}
      .col .x-50 {
         width: 100%;
      }
      .col .x-100 {
         width: 150%;
      }
   


.content-wrapper {
   max-height: 100%;
   position: center;
}

.get-in-touch {

   margin: 0 auto;
   position: relative;

   transform: translateY(-50%);
}
.get-in-touch .title {
     text-align: center;
     font-family: Raleway, sans-serif;
     text-transform: uppercase;
     letter-spacing: 3px;
     font-size: 36px;
     line-height: 48px;
     padding-bottom: 48px;
     margin-left: -22%;
  }



.contact-form .form-field {
      position: relative;
      margin: 32px 0;
   }
   .contact-form  .input-text {
      display: block;
      width: 100%;
      height: 36px;
      border-width: 0 0 2px 0;
      border-color: #000;
      font-family: Lusitana, serif;
      font-size: 18px;
      line-height: 26px;
      font-weight: 400;
   } 
   .contact-form :focus {
         outline: none;
      }
      
      
        .contact-form .label {
            transform: translateY(-24px);
          }
   .label {
      position: absolute;
      left: 20px;
      bottom: 11px;
      font-family: Lusitana, serif;
      font-size: 18px;
      line-height: 26px;
      font-weight: 400;
      color: #888;
      cursor: text;
      transition: transform .2s ease-in-out;
   }
   
   .submit-btn {
      display: block;
      background-color: #000;
      color: #fff;
      font-family: Raleway, sans-serif;
      text-transform: uppercase;
      letter-spacing: 2px;
      font-size: 16px;
      line-height: 24px;
      padding: 8px 16px;
      border: none;
      cursor: pointer;
      width:130px;
      
   }


.note {
   position: absolute;
   left: 0;
   bottom: 10px;
   width: 100%;
   text-align: center;
   font-family: Lusitana, serif;
   font-size: 16px;
   line-height: 21px;
}
.note .link {
      color: #888;
      text-decoration: none;}
      .note :hover {
         text-decoration: none;
      }
  
</style>
