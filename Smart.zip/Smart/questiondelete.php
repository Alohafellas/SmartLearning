<?php
include('connection.php');
include('ques.php');

$id=$_GET['ExerciseID'];
$q="DELETE from exercise where ExerciseID='$id'";
$res=mysqli_query($conn,$q);
if($res)
{
    echo '<script type ="text/JavaScript">';
    echo 'location.replace("admin.php");';
    echo ' </script>';
}
?>