<?php
include('connection.php');

mysqli_query($conn, "INSERT INTO contactus  VALUES (NULL, '" . $name. "', '" . $email. "','" . $subject. "','" . $content. "')");
$insert_id = mysqli_insert_id($conn);
if(!empty($insert_id)) {
$message = "Your contact information is saved successfully";
}
?>