<?php include('connection.php');
session_start();
$id = $_GET['MnoQtyPXZORTE'];
$message = $Home = '';
$_SESSION['ID'] = $id;
if ($_SESSION['ID'] == '') {
		header("location:forgotpswd.php");
}
else
{
if(isset($_POST['submit'])) {
	$password = $_POST['password'];
	$Repassword = $_POST['Repassword'];

	if ($password !== $Repassword) {
		$message = "<div class='alert alert-danger'>Password Not Match..!!</div>";
	}
	else{
	$id_decode = base64_decode($id);
	$query = "UPDATE registration SET UPassword = '$password' WHERE id = '$id_decode' ";
	$result = $conn->query($query);
		if($result){
			$message = "<div class='alert alert-success'>Reset Your Password Successfully..</div>";
			$Home = "<a href='signin.php' class='btn btn-success btn-sm'>Login</a>";
	}else{
		$message = "<div class='alert alert-danger'>Failed to Reset Password..!!</div>";
	}
	}
}
}
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Reset Password</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<script src="https://kit.fontawesome.com/64d58efce2.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="style.css">
  </head>
  <body>
    <div class="wrapper ">
      <div class="title ">Reset Password</div>
      <form  method="POST">
      <?php echo $message; ?>
        <div class="input-field">
        <i class="fas fa-pencil"></i>
          <input type="text" name="password" class="form-control form-control-sm"  required placeholder="New Password">
        </div>
        <div class="input-field">
        <i class="fas fa-eye"></i>
          <input type="password" name="Repassword" class="form-control form-control-sm"  required placeholder="Retype Password">
        </div>
        <button type="submit" name="submit" class="btn btn-success btn-sm ">Reset</button>
  
        
        <?php echo $Home; ?>
  
      </form>
    </div>

  </body>
</html>
