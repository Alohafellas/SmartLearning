<?php

include('connection.php');
include('prof.php');

$id=$_SESSION['ID'];
$name=$_POST['name'];
$email=$_POST['email'];
$gender=$_POST['gender'];

$query="UPDATE registration set UName='$name' , Gender='$gender', Email='$email'  where ID='$id'";
$result=mysqli_query($conn,$query);
    if($result)
    {
        echo '<script type ="text/JavaScript">';
        echo 'location.replace("d.php");';
        echo ' </script>';
        
    }
?>
