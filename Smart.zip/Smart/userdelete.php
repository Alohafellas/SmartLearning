<?php
include('connection.php');
include('users.php');

$id=$_GET['ID'];
$q="DELETE from users where ID='$id'";
$res=mysqli_query($conn,$q);
if($res)
{
    echo '<script type ="text/JavaScript">';
    echo 'location.replace("admin.php");';
    echo ' </script>';
}
?>