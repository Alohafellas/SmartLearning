<?php
include('connection.php');
session_start();
$message='';
 ?>



<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>Quiz Page</title>
  
    <script src="https://kit.fontawesome.com/64d58efce2.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<script src="https://kit.fontawesome.com/64d58efce2.js" crossorigin="anonymous"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

  </head>
   
  <body>
<h1>Chapter Exercise</h1>
<form  method="POST"> 
<div class="quiz_body">
          <div id="questions">
         <?php
         $title=$_GET['LessonTitle'];
         $query = mysqli_query($conn,"SELECT * FROM exercise where LessonTitle='$title'");
      
         if(mysqli_num_rows($query)>0)
         {
          while(!$query|| $row=mysqli_fetch_array($query))
          {  
         ?>
<div>Q. <?php echo  $row['Question'];  ?></div><br>


<p><input type="radio"  onclick="show('correct');" class="op" name='<?php echo $row['ExerciseID'];?>' id="ChoiceA" data-id="<?php echo $row['ExerciseID'];?>" value=" <?php echo $row['OA']; ?>"> <?php echo $row['OA']; ?></p>
<p><input type="radio"   onclick="show('correct');" class="op" name='<?php echo $row['ExerciseID'];?>' id="ChoiceB" data-id="<?php echo $row['ExerciseID'];?>" value=" <?php echo $row['OB']; ?>"> <?php echo $row['OB']; ?></p>
<p><input type="radio"  onclick="show('correct');"  class="op" name='<?php echo $row['ExerciseID'];?>' id="ChoiceC" data-id="<?php echo $row['ExerciseID'];?>"  value=" <?php echo $row['OC']; ?>"> <?php echo $row['OC']; ?></p>
<p><input type="radio"  onclick="show('correct');" class="op" name='<?php echo $row['ExerciseID'];?>' id="ChoiceD" data-id="<?php echo $row['ExerciseID'];?>"  value=" <?php echo $row['OD']; ?>"> <?php echo $row['OD']; ?></p>
<p><input type="radio" checked='checked' style='display:none' value="5" id='radio1_<?php echo $row['ExerciseID'];?>' name='<?php echo $row['ExerciseID'];?>'/>  </p>    
                                                             
<p id="correct" style="display:none">Correct Answer <?php 
echo $row['Answer']  ;
 ?> </p>

</form>


<?php } }?>


</body>
</html>

   
<script> 
function show(id)
{
  var e=document.getElementById(id);
  if(e.style.display=='none')
  e.style.display='block';


}/*
$(document).ready(function (){
  $("op").click(function(){
    $("correct").toggle();
  });
});*/

</script>
<style>
  * {
  padding: 0;
  margin: 0;
  box-sizing: border-box;
}
body {
  font-family: "Lato";
  font-size: 30px;
  
}


h1{
  text-align: center;
  font-family:sans-serif;
  text-decoration: underline;
  letter-spacing: 0.1rem;
}



.quiz_body {
  padding: 30px 30px;
  width: 100vw;
  height: 1000vh;
  background-color:white; 
  margin-left:25%;
  margin-right:25%;
}



.op{
  font-size: 5px;
color:#341f97;
}
.op input[type="radio"]{
  font-size: 15px;
color:#341f97;
}
#correct{
  color:green;
}

.option_group {
  list-style-type: none;
  margin: 30px 0;
}
.optgroup {
  list-style-type: none;
  margin: 30px 0;
}

.option {
  display: block;
  width: 300px;
  background-color: #fff;
  margin-bottom: 20px;
  padding: 15px 20px;
  border-radius: 100px;
  border: 2px solid transparent;
  transition: 0.4s all;
}
.opt {
  display: block;
  width: 300px;
  background-color: #fff;
  margin-bottom: 20px;

  border-radius: 100px;
  border: 2px solid transparent;
  transition: 0.4s all;
}
.option:hover {
  cursor: pointer;
  /* background-color: rgba(255, 255, 255, 0.1); */
  border: 2px solid #341f97;
  color: #341f97;
}
.option.active {
  background-color: #341f97;
  color: #fff;
}




</style>