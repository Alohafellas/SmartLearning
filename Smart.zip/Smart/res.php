

		   
	<?php
     require_once ('connection.php');
	 session_start();
$q = "SELECT * FROM exercise  ";		
$result = mysqli_query ($conn, $q); // Run the query
if ($result) { // If it ran OK, display the records
?>
<form action="answerquiz.php" method="POST">
<table>
<tr>
<td><b> For Each Question There will Only Be One Possible Answer</b> </td>
<br>
</tr>
<?php
// Fetch and print all the records
while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
$question = $row['Question'];
$question_id = $row['ExerciseID'];
$option_1 = $row['OA'];
$option_2 = $row['OB'];
$option_3 = $row['OC'];
$option_4 = $row['OD'];
?>
<tr>
<tr>
<td>
<br>
<br>

<ol><li><?php echo $question;?></li></ol>

1.<input type="radio"   name = "ExerciseID[<?php echo $question_id;?>]" value= "1" /><?php echo $option_1;?> 
<br>
2.<input type="radio"   name = "ExerciseID[<?php echo $question_id;?>]" value= "2" /><?php echo $option_2;?>  
<br>
3.<input type="radio"   name = "ExerciseID[<?php echo $question_id;?>]" value= "3" /><?php echo $option_3;?> 
<br>
4.<input type="radio"   name = "ExerciseID[<?php echo $question_id;?>]" value= "4" /><?php echo $option_4;?> 
<br>
<input type="radio" checked='checked' style='display:none' value="5" id='radio1_<?php echo $row['ExerciseID'];?>' name='<?php echo $row['ExerciseID'];?>'/>  </p>
<td>
<td>
<td>
<td>
</td>
</tr>
<?php
	}

?>


	 </table>
	<br>
	<input type ="submit" value="Submit Quiz">
	
	</form>

<?php	
}
	?>
