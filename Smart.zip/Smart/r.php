
<?php
session_start();
include 'connection.php';
$id = $_SESSION["ID"];
$old=$_POST['old'];
$new=$_POST['new'];
$cnf=$_POST['cnf'];
if(count($_POST)>0) {
$result = mysqli_query($conn,"SELECT * from registration WHERE ID='" . $id . "'");
$row=mysqli_fetch_array($result);
if($old == $row["UPassword"] && $new == $cnf ) {
mysqli_query($conn,"UPDATE registration set UPassword='$new' WHERE ID='" . $id . "'");
header('location:d.php');
} else{
    echo '<script type ="text/JavaScript">';  
    echo 'alert("wrong Password")';  
    echo '</script>';
    echo '';
    
    echo '<script type ="text/JavaScript">';
    echo 'location.replace("d.php");';
    echo ' </script>';
}

}

?>
