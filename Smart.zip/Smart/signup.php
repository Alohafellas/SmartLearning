<?php
include ('connection.php');
session_start();
$message = '';
if(isset($_POST['submit'])) {
$name=$_POST['name'];
$gender=$_POST['gender'];
$email = $_POST['email'];
$pswd = $_POST['pswd'];

$pattern = "^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$^";  
$sql = "INSERT INTO registration VALUES (NULL,'$name','$gender','$email','$pswd')";   
$sql1="SELECT * from registration where  Email='$email'";
$res=mysqli_query($conn, $sql1);

 if (strlen ($pswd) != 6) {  
   $message = "<div class='alert alert-danger'>Password must be of 6 characters..!!</div>";

    }

  else if (!preg_match ("/^[a-zA-Z ]*$/", $name) )
   {  
           $message = "<div class='alert alert-danger'>Name should be alphabets!!</div>";

  }
  else if (!preg_match ("/^[a-zA-Z ]*$/", $gender) )
   {  
           $message = "<div class='alert alert-danger'>Gender should be alphabets!!</div>";

  }
 else if (!preg_match ($pattern, $email) )

 {  
   $message = "<div class='alert alert-danger'>Email not valid!!</div>";

         
}

else if(!$res || mysqli_num_rows($res)>0)
{
  while(!$res|| $row=mysqli_fetch_array($res) )
  {
    $mail=$row['Email'];
    if($email==$mail)
    {
      $message = "<div class='alert alert-danger'>Email already exists!!</div>";
    }
  }
}

else if(mysqli_query($conn, $sql)){
   $message = "<div class='alert alert-success'>Registered Successfully..</div>";

   header('location:signin.php');
}  


else{
   $message = "<div class='alert alert-danger'>Some Error Occurred!!</div>";

}
}

?>

   
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Edit Profile</title>
    <script
      src="https://kit.fontawesome.com/64d58efce2.js" crossorigin="anonymous"></script>
      <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<script src="https://kit.fontawesome.com/64d58efce2.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="style.css">
  </head>
  <body>
    <div class="wrapper">
      <div class="title">Create Account</div>
      <form  method="POST" >
      <?php echo $message; ?>
        <div class="input-field">
          <i class="fas fa-user"></i>
        <input type="text" id="name" name="name"   required placeholder="Name">
        <span id="error"></span>
      </div>
      
    <div class="input-field">
      <i class="bx bxs-user-pin"></i>
      <input type="text" id="gender" name="gender" required placeholder="Gender">
      <span id="error"></span>
  </div><!--
  <div class="input-field">
  <select name="grade">
    <option value="Select Grade">Select Grade</option>
    <option value="Kindergarten" >Kindergarten</option>
    <option value="Grade 1">Grade 1</option>
    <option value="Grade 2" >Grade 2</option>
    <option value="Grade 3 ">Grade 3</option>
    <option value="Grade 4">Grade 4</option>
    <option value="Grade 5">Grade 5</option>
  </select>
</div>-->
        <div class="input-field">
            <i class="fas fa-envelope"></i>
          <input type="text" id="email" name="email" required placeholder="Email">
        </div>
        <div class="input-field">
          <i class="fas fa-lock"></i>
        <input type="password" id="pswd" name="pswd" required placeholder="Password">
      </div>
      <div class="field">
        <input type="submit"  name="submit" value="Sign Up" >
      </div>
        <div class="signup-link">Already a member? <a href="signin.php">Login</a></div>
      </form>
    </div>

  </body>
</html>
