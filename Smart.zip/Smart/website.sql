-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 05, 2021 at 02:37 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `website`
--

-- --------------------------------------------------------

--
-- Table structure for table `contactus`
--

CREATE TABLE `contactus` (
  `ID` int(3) NOT NULL,
  `Name` text NOT NULL,
  `Subject` text NOT NULL,
  `Email` varchar(500) NOT NULL,
  `Message` mediumtext NOT NULL,
  `Timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contactus`
--

INSERT INTO `contactus` (`ID`, `Name`, `Subject`, `Email`, `Message`, `Timestamp`) VALUES
(26, 'Shreya', 'test', 'alohafellas93@gmail.com', 'test mail ', '2021-07-04 10:54:33'),
(27, 'Priyanka', 'tesxt mail', 'impmailhere@gmail.com', 'query for admission', '2021-07-04 11:04:14');

-- --------------------------------------------------------

--
-- Table structure for table `exercise`
--

CREATE TABLE `exercise` (
  `ExerciseID` int(4) NOT NULL,
  `LessonTitle` varchar(256) NOT NULL,
  `Question` varchar(500) NOT NULL,
  `OA` varchar(256) NOT NULL,
  `OB` varchar(256) NOT NULL,
  `OC` varchar(256) NOT NULL,
  `OD` varchar(256) NOT NULL,
  `Answer` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `exercise`
--

INSERT INTO `exercise` (`ExerciseID`, `LessonTitle`, `Question`, `OA`, `OB`, `OC`, `OD`, `Answer`) VALUES
(10, 'Basic Numbers 1', 'What comes after 6?', ' 3', '7', '8', ' 9', '7'),
(12, 'BasicNumbers 2', 'What is the number name of 5 ?', ' One', 'Six', 'Four', ' Five', 'Five');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `ID` int(11) NOT NULL,
  `UName` text NOT NULL,
  `Email` varchar(256) NOT NULL,
  `RateMsg` text NOT NULL,
  `Comment` varchar(500) NOT NULL,
  `Timestamp` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`ID`, `UName`, `Email`, `RateMsg`, `Comment`, `Timestamp`) VALUES
(70, 'Vini', 'impmailhere@gmail.com', 'Very Good', 'Nice', '2021-06-18'),
(71, 'Siya', 'alohafellas93@gmail.com', 'Awesome', 'Excellent', '2021-06-07');

-- --------------------------------------------------------

--
-- Table structure for table `lesson`
--

CREATE TABLE `lesson` (
  `LessonID` int(4) NOT NULL,
  `LessonChapter` varchar(256) NOT NULL,
  `LessonTitle` varchar(255) NOT NULL,
  `FileLocation` text NOT NULL,
  `Category` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `lesson`
--

INSERT INTO `lesson` (`LessonID`, `LessonChapter`, `LessonTitle`, `FileLocation`, `Category`) VALUES
(28, '1', 'Basic Numbers 1', 'videos/basic1.mp4', 'video'),
(30, '2', 'BasicNumbers 2', 'videos/basic2.mp4', 'video'),
(31, '3', 'Basic Numbers 3', 'videos/basic3.mp4', 'video');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `ID` int(3) NOT NULL,
  `UName` text NOT NULL,
  `Gender` text NOT NULL,
  `Email` varchar(500) NOT NULL,
  `UPassword` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`ID`, `UName`, `Gender`, `Email`, `UPassword`) VALUES
(29, 'Vini', 'Male', 'impmailhere@gmail.com', '123456'),
(39, 'Siya', 'Female', 'alohafellas93@gmail.com', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `ID` int(3) NOT NULL,
  `UName` text NOT NULL,
  `Email` varchar(500) NOT NULL,
  `UPass` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`ID`, `UName`, `Email`, `UPass`) VALUES
(13, 'Shreya', 'impmailhere@gmail.com', 789456),
(14, 'Vibha', 'abcd@gmail.com', 123456),
(15, 'Riya', 'riya@gmail.com', 123456);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contactus`
--
ALTER TABLE `contactus`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `exercise`
--
ALTER TABLE `exercise`
  ADD PRIMARY KEY (`ExerciseID`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `lesson`
--
ALTER TABLE `lesson`
  ADD PRIMARY KEY (`LessonID`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `ID` (`ID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `ID` (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contactus`
--
ALTER TABLE `contactus`
  MODIFY `ID` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `exercise`
--
ALTER TABLE `exercise`
  MODIFY `ExerciseID` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=75;

--
-- AUTO_INCREMENT for table `lesson`
--
ALTER TABLE `lesson`
  MODIFY `LessonID` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `ID` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `ID` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
