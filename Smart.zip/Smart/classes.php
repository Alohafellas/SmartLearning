
<head>
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons"></head>
<h1>Our Classes</h1>
<div class="wrapper">
  <div class="row">
    <div class="col">
      <div class="card" id="crd-00">
        <button class="icon btn-no-decoration" onclick="show('crd-00')">
          <span class="material-icons material-icons-outlined">
            add
          </span>
        </button>
        <img src="https://images.unsplash.com/photo-1484820540004-14229fe36ca4?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=634&q=80" class="cover" alt="">
        <div class="body">
          <hr class="line">
          <div class="description">
            <div class="p">
            Video Lectures for Kindergarten
            </div>
          </div>
          <button class="btn-no-decoration"><a href="videos.php">View</a></button>
        </div>
      </div>
    </div>
    <div class="col">
      <div class="card" id="crd-01">
        <button class="icon btn-no-decoration" onclick="show('crd-01')">
          <span class="material-icons material-icons-outlined">
            add
          </span>
        </button>
        <img src="https://images.unsplash.com/photo-1501686637-b7aa9c48a882?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=675&q=80" class="cover" alt="">
        <div class="body">
          <hr class="line">
          <div class="description">
            <div class="p">
            Video Lectures for Grade 1
            </div>
          </div>
          <button class="btn-no-decoration"><a href="videos.php">View</a></button>
        </div>
      </div>
    </div>
    <div class="col">
      <div class="card" id="crd-02">
        <button class="icon btn-no-decoration" onclick="show('crd-02')">
          <span class="material-icons material-icons-outlined">
            add
          </span>
        </button>
        <img src="images/kg.jpg" class="cover" alt="">
        <div class="body">
          <hr class="line">
          <div class="description">
            <div class="p">
              Video Lectures for Grade 2
            </div>
          </div>
          <button class="btn-no-decoration"><a href="videos.php">View</a></button>
        </div>
      </div>
    </div>
    <div class="col">
      <div class="card" id="crd-03">
        <button class="icon btn-no-decoration" onclick="show('crd-03')">
          <span class="material-icons material-icons-outlined">
            add
          </span>
        </button>
        <img src="https://images.unsplash.com/photo-1599042049168-c3336f495314?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1050&q=80" class="cover" alt="">
        <div class="body">
          <hr class="line">
          <div class="description">
            <div class="p">
            Video Lectures for Grade 3
            </div>
          </div>
          <button class="btn-no-decoration"><a href="videos.php">View</a></button>
        </div>
      </div>
    </div>
    <div class="col">
      <div class="card" id="crd-04">
        <button class="icon btn-no-decoration" onclick="show('crd-04')">
          <span class="material-icons material-icons-outlined">
            add
          </span>
        </button>
        <img src="images/g1.jpg" class="cover" alt="">
        <div class="body">
          <hr class="line">
          <div class="description">
            <div class="p">
            Video Lectures for Grade 4
            </div>
          </div>
          <button class="btn-no-decoration"><a href="videos.php">View</a></button>
        </div>
      </div>
    </div>
    <div class="col">
      <div class="card" id="crd-05">
        <button class="icon btn-no-decoration" onclick="show('crd-05')">
          <span class="material-icons material-icons-outlined">
            add
          </span>
        </button>
        <img src="https://images.unsplash.com/photo-1568828668638-b1b4014d91a2?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1072&q=80" class="cover" alt="">
        <div class="body">
          <hr class="line">
          <div class="description">
            <div class="p">
            Video Lectures for Grade 5
            </div>
          </div>
          <button class="btn-no-decoration"><a href="videos.php">View</a></button>
        </div>
      </div>
    </div>
  </div>
</div>
<style>
    * {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: "Montserrat", sans-serif;
}
a{
    text-decoration: none;
    color:white;
}
.btn-no-decoration {
  text-decoration: none;
  border: none;
}

.wrapper {
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 100vh;

}
h1{
    text-align: center;
    font-family:sans-serif;
    text-decoration: underline;
    letter-spacing: 0.1rem;
}
.row {
  width: 100%;
  max-width: 1024px;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  justify-content: space-around;
  align-content: space-around;
}

.col {
  width: 300px;
  height: 400px;
  padding: 10px;
}

.card img {
  width: 100%;
  height: 100%;
  transition: filter 1s;
}

.cover {
  object-fit: cover;
}

.card .icon {
  position: absolute;
  right: 30px;
  bottom: 36px;
  z-index: 1;
  padding: 10px;
  background: rgb(241, 70, 70);
  border-radius: 50%;
  color: #fff;
  cursor: pointer;
  box-shadow: 2px 2px 16px rgb(199, 45, 45);
}

.card .icon span {
  transition: 1s;
}

.card .icon:active span {
  transform: scale(0);
}

.card {
  position: relative;
  width: 100%;
  height: 100%;
  background-repeat: no-repeat;
  background-size: cover;
  border-radius: 20px;
  overflow: hidden;
  box-shadow: 2px 5px 10px #76d7c4;
}

.card .body {
  position: absolute;
  left: 0;
  top: 324px;
  width: 100%;
  height: 90%;
  background: #fafafa;
  border-top-left-radius: 20px;
  border-top-right-radius: 20px;
  transition: top 1s;
  display: inline-flex;
  flex-direction: column;
  align-content: space-between;
  justify-content: space-between;
  align-items: center;
}

.card .body button {
  cursor: pointer;
  width: min-content;
  padding: 8px 16px 8px 16px;
  margin-bottom: 56px;
  border-radius: 20px;
  color: #fff;
  background: #5dade2;
  margin-top: -5%;
}

button.icon {
  width: 50px;
  height: 50px;
}

.card .body button:hover {
  background: #3498db;
}

.card .body .description {
  height: 40%;
  padding: 15px;
  overflow: hidden;
}

.card .body .description .p {
  text-align: center;
  overflow: hidden;
  display: -webkit-box;
  -webkit-line-clamp: 5;
  -webkit-box-orient: vertical;
}

.card .body.visible {
  top: 40px;
}

.card img.visible {
  filter: brightness(60%);
  -webkit-filter: brightness(60%);
}

.card .body .line {
  width: 30%;
  height: 5px;
  background: #cacfd2;
  margin-left: auto;
  margin-right: auto;
  margin-top: 20px;
  border-radius: 5px;
  border-color: transparent;
}

@media screen and (max-width: 300px) {
  .col {
    width: 100%;
  }
}

</style>
<script>
    function show(id) {
  const card = document.querySelector("#" + id + " .body");
  const cardImg = document.querySelector("#" + id + " img");
  const icon = document.querySelector("#" + id + " .icon span");

  console.log(id);
  card.classList.toggle("visible");
  if (cardImg.classList.toggle("visible")) icon.innerHTML = "remove";
  else icon.innerHTML = "add";
}

</script>