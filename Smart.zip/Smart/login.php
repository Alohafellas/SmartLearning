
<?php

session_start();
include 'connection.php';

$email=$_POST['email'];
$pswd=$_POST['pswd'];
$pattern = "^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$^";  
$query="SELECT * from registration where Email='$email' and UPassword='$pswd'";
$result=mysqli_query($conn,$query);
$total=mysqli_num_rows($result);
if($total!=0)
{
  while(!$result || $row= mysqli_fetch_array($result))
  {
    $_SESSION['ID']=$row['ID'];
    $_SESSION['Email'] = $email; 
    header('Location:d.php');  
  }
    
}  
 

?>