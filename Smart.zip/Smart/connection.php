<?php

$servername ="localhost" ;
$username="root";
$password="";
$dbname="website";
$conn = mysqli_connect("localhost", "root", "", "website");


if($conn === false){
   die("ERROR: Could not connect. "
	   . mysqli_connect_error());
}
?>