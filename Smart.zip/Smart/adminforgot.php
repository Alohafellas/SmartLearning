<?php include('connection.php');
session_start();
$message = $link = '';
if(isset($_POST['submit'])) {
	$email = $_POST['email'];
	$query = "SELECT * FROM users WHERE Email = '".$email."'";
	$result = $conn->query($query);
if($result->num_rows > 0){
	while($row = $result->fetch_assoc()){
		$id = $row['ID'];
		$id_encode = base64_encode($id);
		$link = "<a href='adminreset.php?MnoQtyPXZORTE=$id_encode' class='btn btn-info btn-sm'>Redirect</a>";
	}
	}else{
		$message = "<div class='alert alert-danger'>Invalid Email..!!</div>";
	}
	}
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Forgot Password</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
    <script src="https://kit.fontawesome.com/64d58efce2.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="style.css">
  </head>
  <body>
    <div class="wrapper">
      <div class="title ">Forgot Password</div>
      <form method="POST">
      <?php echo $message; ?>
        <div class="input-field ">
            <i class="fas fa-envelope"></i>
          <input type="text" name="email" class="form-control form-control-sm"  required placeholder="Email">
        </div>
        <button type="submit" name="submit" class="btn btn-success btn-sm">Continue</button>
  
        
          <?php echo $link; ?>
  
      </form>
    </div>

  </body>
</html>
