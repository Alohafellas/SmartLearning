<?php

include('connection.php');
include('userprofile.php');
if(isset($_POST['submit']))
{


$id=$_SESSION['ID'];
//$name=$_POST['name'];
//$email=$_POST['email'];
$gender=$_POST['gender'];

$query="UPDATE registration set  Gender='$gender'  where ID='$id'";
$result=mysqli_query($conn,$query);
    if($result)
    { 
        echo '<script type ="text/JavaScript">';
        echo 'location.replace("d.php");';
        echo ' </script>';

  
    }
}
?>

