<?php
include('connection.php');
include('lessons.php');

 $id=$_GET['LessonID'];
$q="DELETE from lesson where LessonID='$id'";
$res=mysqli_query($conn,$q);
if($res)
{
    
    echo '<script type ="text/JavaScript">';
    echo 'location.replace("admin.php");';
    echo ' </script>';
}
?>