
 <?php
        include('connection.php');

        $query="SELECT UName , RateMsg, Comment,Timestamp from feedback ";
          $result=mysqli_query($conn,$query);
          if (mysqli_num_rows($result) > 0)
          {
               while($rows=mysqli_fetch_array($result))
              {
                ?>
            
              
     

<body>
      
  <div class="reviewcard">
    <div class="propicbox"><img src="images/User-512.png" class="propic"></div>
    
    <div class="reviewerbox">
    <h1><a href="" class="reviewername" target="_blank"><?php  echo $rows['UName']; ?></a> <img src="https://preview.checchiadesign.com/code/reviewcard/img/review-icon.png" width="20px"> </h1>
    <p class="reviewdate"><?php  echo $rows['Timestamp']; ?></p>
    </div>
    <p class="review">
  <?php  echo $rows['RateMsg']; ?>
      </p>
  <p class="review">

      <?php  echo $rows['Comment']; ?></p>
  

    </div>


    

  
</body>
<?php 
              } 
           }
       ?>
<style>
    
body {
  margin: 0;
  padding: 0 30px;

  justify-content: center;
  align-items: center;
  height: 100vh;
  background: #f0f1f3;
}



.reviewcard {
  box-shadow: 0px 20px 60px -20px rgba(0, 0, 0, 0.15);
  box-sizing: border-box;
  padding: 30px 50px;
  font-family: sans-serif;
  display: inline-block;

justify-content: space-between;
margin-left:8%;
margin-top: 3%;
  font-weight: 400;
  border-radius: 15px;
  background: #fff;
  width: 25%;

}

.propicbox {
    float: left;
}

.propic {
    width: 50px;
    border-radius: 50px;   
}

.reviewerbox {
    margin: -7px 0 0 60px;
    
}

h1 {
    font-size: 16px;
    line-height: 1.5em;
    font-weight: 400;
    color: #636972;
}

.reviewername {
    color: #39599a;
    font-size: 18px;
    font-weight: 600;
}

a, a:visited, a:hover {
    color: #39599a;
    text-decoration: none;
}

.reviewdate {
    font-size: 14px;
    line-height: 1em;
    font-weight: 400;
    color: #636972;
    margin: -10px 0 0 0
}


.review {
  box-sizing: border-box;
  font-size: 16px;
  line-height: 1.5em;
}



</style>