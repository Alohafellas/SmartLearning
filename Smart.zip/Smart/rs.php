
<?php
session_start();
include 'connection.php';
$id = $_SESSION["UName"];
$old=$_POST['old'];
$new=$_POST['new'];
$cnf=$_POST['cnf'];
if(count($_POST)>0) {
$result = mysqli_query($conn,"SELECT * from users WHERE UName='" . $id . "'");
$row=mysqli_fetch_array($result);
if($old == $row["UPass"] && $new == $cnf ) {
mysqli_query($conn,"UPDATE users set UPass='$new' WHERE UName='" . $id . "'");
header('location:admin.php');
} else{
    echo '<script type ="text/JavaScript">';  
    echo 'alert("wrong Password")';  
    echo '</script>';
    echo '';
    
    echo '<script type ="text/JavaScript">';
    echo 'location.replace("admin.php");';
    echo ' </script>';
}
}
?>
