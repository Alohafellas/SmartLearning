<?php

$servername ="localhost" ;
$username="root";
$password="12345";
$dbname="website";
$conn = mysqli_connect("localhost", "root", "12345", "website");
// Check connection
if($conn === false){
    die("ERROR: Could not connect. ". mysqli_connect_error());
 }

    $email = $_POST['email'];
    $pswd = $_POST['pswd'];
    $query="SELECT * from registration where  Email='$email' and UPassword='$pswd'";

    $result=mysqli_query($conn,$query);
    $total=mysqli_num_rows($result);
    if($total==1)
    {
        session_start();
        $_SESSION['website']=true;
        header('Location:d.html');
 
    }
    else{
        echo 'Login Failed';
    }
// Close connection
mysqli_close($conn);
?>


