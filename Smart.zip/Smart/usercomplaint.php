<?php
include ('connection.php');
$message = '';
if(isset($_POST['submit'])) {
$name=$_POST['name'];
$subject=$_POST['subject'];
$email = $_POST['email'];
$msg = $_POST['msg'];
$pattern = "^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$^";  
$sql = "INSERT INTO contactus VALUES (NULL,'$name','$subject','$email','$msg',NULL)";   


$to = "shreyatiwari9336@gmail.com";

$headers =  'MIME-Version: 1.0' . "\r\n"; 
$headers = "From: " . $name . "<". $email .">\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n"; 



  if (!preg_match ($pattern, $email) )

 {  
   $message = "<div class='alert alert-danger'>Email not valid!!</div>";

         
}


else if(mysqli_query($conn, $sql)){
  if (mail($to,$subject,$msg,$headers)){
    $message= "<div class='alert alert-success'>E-Mail Sent successfully, we will get back to you soon...</div>";
  }
 else {
  $message = "<div class='alert alert-danger'>email not sent!!</div>";
}}

 


else{
   $message = "<div class='alert alert-danger'>Some Error Occurred!!</div>";

}
}

?>

    <section id="contact" class="contact">

        <h1 class="heading">Any Queries ?</h1>
        
        
        <div class="row">
            <div class="image">
                <img src="images/Contactus.svg" alt="">
              </div>
        
          <div class="form-container">
            <form  method="POST">
        <?php echo $message ;?>
              <div class="inputBox">
                <input type="text" name="name" required placeholder=" Name">
                <input type="text" name="subject"  required placeholder="Subject">
              </div>
              <input type="email" name="email" required placeholder="Email">
              <textarea  id="" cols="30" rows="10" name="msg" required placeholder="Message"></textarea>
              <input type="submit"  class="showMsg" name="submit" value="send">
        
            </form>
          </div>
        
      
        </div>
        
        </section>
        <style>
          .contact{
  min-height: 100vh;
  width: 100vw;
  text-align: center;
}

.contact .row{
  display: flex;
  align-items: center;
  justify-content: center;
}

.contact .row .image img{
  height: 50vh;
  width:20vw;
}

.contact .row .form-container{
  width: 50%;
  text-align: left;
  padding:0 5rem;
}

.contact .row .form-container input, textarea{
  outline: none;
  border:none;
  height:4rem;
  background: none;
  border-radius: .5rem;
  box-shadow: .2rem .2rem .5rem rgba(0,0,0,.2);
  padding:0 1rem;
  margin:1rem 0;
  font-size: 1.6rem;
}

.contact .row .form-container .inputBox{
  width: 100%;
  display: flex;
  justify-content: space-between;
}

.contact .row .form-container .inputBox input[type="text"]{
  width: 49%;
  
}

.contact .row .form-container input[type="email"]{
  width: 100%;
  text-transform: none;
}

.contact .row .form-container textarea{
  width: 100%;
  height:20rem;
  padding:1rem; 
  resize: none;
}

.contact .row .form-container input[type="submit"]{
  background-color:#6C5CE7;
  color:white;
  cursor: pointer;
  height:4rem; 
  width: 10rem;;
}

.contact .row .form-container input[type="submit"]:hover{
  opacity: .8;
}

        </style>