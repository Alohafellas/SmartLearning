
<?php

session_start();
include 'connection.php';
$message = '';
if(isset($_POST['submit'])) {
$email=$_POST['email'];
$pswd=$_POST['pswd'];
$pattern = "^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$^";  
$query="SELECT * from registration where Email='$email' and UPassword='$pswd'";
$result=mysqli_query($conn,$query);
$total=mysqli_num_rows($result);
if (strlen ($pswd) != 6) {  
  $message = "<div class='alert alert-danger'>Password must be of 6 characters..!!</div>";

   }

else if (!preg_match ($pattern, $email) )

{  
  $message = "<div class='alert alert-danger'>Email not valid!!</div>";

        
}

else if($total!=0)
{ 
 
  while(!$result || $row= mysqli_fetch_array($result))
  {
   
    
      $message = "<div class='alert alert-success'>Logged In..</div>";

      $_SESSION['ID']=$row['ID'];
      $_SESSION['UName']=$row['UName'];
      $_SESSION['Email'] = $email; 
      header('Location:d.php');  
    
   
  }
    
} 
else {
  $message = "<div class='alert alert-danger'>Incorrect Email or Password</div>";
}
}

?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Login</title>
    <script src="https://kit.fontawesome.com/64d58efce2.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<script src="https://kit.fontawesome.com/64d58efce2.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="style.css">
  </head>
  <body>
    <div class="wrapper">
      <div class="title">Login</div>
      <form  method="POST">
      <?php echo $message; ?>
        <div class="input-field">
            <i class="fas fa-envelope"></i>
          <input type="text" name="email" required placeholder="Email">
        </div>
        <div class="input-field">
            <i class="fas fa-lock"></i>
          <input type="password" name="pswd" required placeholder="Password">
        </div>
        <div class="content">
         <!-- <div class="checkbox">
            <input type="checkbox" id="remember-me">
            <label for="remember-me">Remember me</label>
          </div>-->
          <div class="pass-link"><a href="forgotpswd.php">Forgot password?</a></div>
        </div>
        <div class="field">
          <input type="submit" name="submit" value="Login" >
        </div>
        <div class="signup-link">Not a member? <a href="signup.php">Signup now</a></div>
       <!-- <div class="signup-link"> <a href="adminlogin.php">Admin Login</a></div>-->
      </form>
    </div>

  </body>
</html>
