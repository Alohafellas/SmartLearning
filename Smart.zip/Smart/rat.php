<?php
include('connection.php');
include('d.php');
session_start();

if(isset($_POST['submit']))
{

  $name=$_POST['name'];
  $email=$_SESSION['Email'];
  $rmsg=$_POST['rate'];
  $cmnt=$_POST['msg'];


  $query = "INSERT INTO `feedback`  VALUES (NULL,$name,$email,$rmsg,$cmnt,Null)";   
$result = mysqli_query($conn,$query) or die(mysqli_Connect_error());

  if (!mysqli_query($conn, $query)) {
    echo "Error: " . mysqli_error($conn);
}
  if($result)
  {
    header('location.d.php');
  }

}
  

?>