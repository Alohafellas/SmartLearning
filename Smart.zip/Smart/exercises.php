
<h1>Chapter Exercises</h1>
<?php 
include('connection.php');
$query=mysqli_query($conn,"SELECT * from lesson ");

if(mysqli_num_rows($query)>0)
{
    while($row=mysqli_fetch_array($query))
    {
      $name= $row['LessonTitle'];

    
?>
<div class="card-container">
<div class="card">
    <div class="card-circle">
      <i class="fas fa-pencil-alt fa-4x"></i>
  </div>
  <div class="text-content">

  <a href="quiz.php?LessonTitle=<?php echo $row['LessonTitle']; ?>" > <span class=card-title><strong><?php echo $name;?></strong></span></a>
   
  </div>
</div>
</div>
<?php }}?>
<style>
.card-container {
  display: inline-block;
  justify-content: space-evenly;
  margin-left:15%;
  margin-top: 6%;
  background-color:lightseagreen;
}
.card{
    
  display: flex;
  flex-wrap: wrap;
  flex-direction:row-reverse;
  justify-content: space-around;

  align-items: center;


  width: 200px;
  height: auto;
  position: relative;
  border-radius: 2px;
  background-color:#fff;
  box-shadow: 0 2px 2px 0 rgba(0, 0, 0, 0.14), 0 1px 5px 0 rgba(0, 0, 0, 0.12), 0 3px 1px -2px rgba(0, 0, 0, 0.2);
  text-align: center;
  margin: 20px;
  padding: 20px;
  transition: all 0.3s cubic-bezier(.25,.8,.25,1);
}


.card-circle{
  display: flex;
  justify-content: center;
  align-items: center;
  width: 80px;
  height: 80px;
  border: 2px solid #e0e0e0;
  border-radius: 50%;
  margin-bottom: 10px;
  padding: 20px;
}
a{
    color:black;
    text-decoration: none;
}
.text-content{
  font-family: 'Roboto', sans-serif;
  padding-top: 20px;
}

.card-title{
  font-size: 24px;
  font-weight: 500;
  line-height: 48px;
}

p{
  font-size: 15px;
  font-weight: 400;
  line-height: 30px;
}

i{
  color: #2196F3;
}

.fa-css3{
  color: #fff;
}

.card:hover{
    box-shadow: 0 14px 28px rgba(0,0,0,0.25), 0 10px 10px rgba(0,0,0,0.22);
}
h1{
    text-align: center;
    text-decoration: underline;
    font-family: sans-serif;
    letter-spacing: 0.1rem;
}

</style>